import tkinter as tk
from PIL import Image, ImageTk
from random import choice

def play(user_choice):
    choices = ["rock", "paper", "scissor"]
    computer_choice = choice(choices)
    
    if user_choice == computer_choice:
        result = "It's a Tie!"
    elif (user_choice == "rock" and computer_choice == "scissor") or \
         (user_choice == "paper" and computer_choice == "rock") or \
         (user_choice == "scissor" and computer_choice == "paper"):
        result = "You Win!"
        scores["player"] += 1
    else:
        result = "Computer Wins!"
        scores["computer"] += 1
    
    result_label.config(text=f"Your Choice: {user_choice}\nComputer's Choice: {computer_choice}\n{result}")
    score_label.config(text=f"Your Score: {scores['player']}\nComputer Score: {scores['computer']}")

root = tk.Tk()
root.title("Scissor Paper Rock @Diwas")

scores = {"player": 0, "computer": 0}

image_path = r"C:\Users\tejas\Desktop\Rock_Paper_Scissor\Rock_Paper_Scissor.jpg"
image = Image.open(image_path)
image = image.resize((200, 200), Image.Resampling.LANCZOS) 
image_tk = ImageTk.PhotoImage(image)
image_label = tk.Label(root, image=image_tk)
image_label.grid(row=0, column=0, columnspan=3, pady=10)

rock_button = tk.Button(root, text="Rock", bg="yellow", font=("Helvetica", 14), command=lambda: play("rock"))
rock_button.grid(row=1, column=0, padx=10, pady=10)

paper_button = tk.Button(root, text="Paper", bg="pink", font=("Helvetica", 14), command=lambda: play("paper"))
paper_button.grid(row=1, column=1, padx=10, pady=10)

scissor_button = tk.Button(root, text="Scissor", bg="red", font=("Helvetica", 14), command=lambda: play("scissor"))
scissor_button.grid(row=1, column=2, padx=10, pady=10)

result_label = tk.Label(root, text="Make your move!", font=("Helvetica", 12))
result_label.grid(row=2, column=0, columnspan=3, pady=10)

score_label = tk.Label(root, text="Your Score: 0\nComputer Score: 0", font=("Helvetica", 12))
score_label.grid(row=3, column=0, columnspan=3, pady=10)

footer_label = tk.Label(root, text="@Diwas Pandey", font=("Helvetica", 10), fg="gray")
footer_label.grid(row=4, column=0, columnspan=3)

root.mainloop()
